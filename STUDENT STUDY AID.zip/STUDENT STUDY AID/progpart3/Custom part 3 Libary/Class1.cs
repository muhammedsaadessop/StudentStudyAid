﻿namespace Custom_part_3_Libary
{
    public class Class1
    {    // NORMAL PAGES STR ONLY CHNAGE THE SERVER NAME:MOMOESSOPNICEPC\\SQLEXPRESS
        public  string? str = "Data Source=MOMOESSOPNICEPC\\SQLEXPRESS;Initial Catalog=PART2PROG;Integrated Security=True";

        // CONNECTION FOR THE GRPAH CHANGE THE SERVER NAME MOMOESSOPNICEPC\\SQLEXPRESS AND ENSURE IT HAS Trust Server Certificate=true";
        public string? str2 = "Data Source=MOMOESSOPNICEPC\\SQLEXPRESS;Initial Catalog=PART2PROG;Integrated Security=True;Trust Server Certificate=true";

        // GETTERS AND SETTERS FPR THE MODULE CLASS
        public string? Message { get; set; }
        public string? Email { get; set; }
        public string? Dates { get; set; }
        public string? Error { get; set; }
        public double? W1 { get; set; }
        public double? W2 { get; set; }
        public double? W3 { get; set; }
        public double? W4 { get; set; }
        public string? Date1 { get; set; }
        public string? Date2 { get; set; }
        public string? Date3 { get; set; }
        public string? Date4 { get; set; }
        public double? hours1 { get; set; }
        public double? hours2 { get; set; }
        public double? hours3 { get; set; }
        public double? hours4 { get; set; }
        
        public double? credits1 { get; set; }
        public double? credits2 { get; set; }
        public double? credits3 { get; set; }
        public double? credits4 { get; set; }


        public double? result1{ get; set; }
        public double? result2 { get; set; }
        public double? result3 { get; set; }
        public double? result4{ get; set; }


        public void Singlemod1()
        //MOUDLE 1 CALCULATION
        {// EACH MODULE HAS INDIVIDUAL CALCULATIONS FOR MORE CONTROL 



            result1 = (credits1 * 10 / W1) - hours1;



        }
        public void Singlemod3()
        {// MODULE 2 CALCULATIO 
            result3 = (credits3 * 10 /W3 )- hours3;



        }
        public void Singlemod2()
        {// MODULE 3 CALULATATION
            result2 = (credits2 * 10 / W2) - hours2;

        }
        public void Singlemod4()
        { //MODULE 4 CALCULATION 
            result4 = (credits4 * 10 / W4) - hours4;

        }
    }

}