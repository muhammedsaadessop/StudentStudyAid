using Custom_part_3_Libary;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Graph;
using Microsoft.Graph.TermStore;
using System.Data;
using System.Data.SqlClient;
using Xceed.Wpf.Toolkit;

namespace progpart3.Pages
{
    public class MODULESModel : PageModel
    { // MODULE GETTER AND  SETTER FOR DATA 
        Class1 inout = new Class1();
        public string? users { get; set; }
        public string? heading1 { get; set; }
        public string? heading2 { get; set; }
        public string? heading3 { get; set; }
        public string? heading4 { get; set; }
        public string? Name { get; set; }
        public string? SetName { get; set; }
        public string? Message { get; set; }
        public string? Message1 { get; set; }
        public string? Message2 { get; set; }
        public string? Message3 { get; set; }
        public string? Message4 { get; set; }
        public string? Email { get; set; }
        public string? Dates { get; set; }
        public string? Error { get; set; }
        public string? W1 { get; set; }
        public string? W2 { get; set; }
        public string? W3 { get; set; }
        public string? W4 { get; set; }
        public string? Date1 { get; set; }
        public string? Date2 { get; set; }
        public string? Date3 { get; set; }
        public string? Date4 { get; set; }
        public string? hours1 { get; set; }
        public string? hours2 { get; set; }
        public string? hours3 { get; set; }
        public string? hours4 { get; set; }

        public string? credits1 { get; set; }
        public string? credits2 { get; set; }
        public string? credits3 { get; set; }
        public string? credits4 { get; set; }

     // START METHOD FOR USER VALIDATION
        public void OnGet()
        {             string output = "MODULE 1 DETAILS ";
            Message = output;

            try
            { // VALIDATING THE USER WHEN THEY CLICK ON THE PAGE
                string? message = null;
                message = User.Identity.GetUserName();
                if (message == null)
                { // IF NO USER IT WILL REDIRECT TO THE LOG IN PAGE
                    Error = "Warning! you have not logged in";
                    Response.Redirect("/Identity/Account/Login");
                }
                else
                { // IF THERE IS A USER IT WILL AUTOFILL THE FORMS 
                    Email = message?.ToString();
                   
                    SqlConnection conn = new SqlConnection(inout.str);
                    //opening the connection 
                    conn.Open();
                    string selectquery = $"Select students.passkey from students where student_num ='{Email}';";
                    SqlCommand mysql = new SqlCommand(selectquery, conn);
                    SqlDataReader reader = mysql.ExecuteReader();
                    // reading the data
                    reader.Read();
                    SetName = reader[0].ToString();
                    reader.Close();
                }
            }
            // IF THE USER IS LOGGED IN BUT NOT SUBMITTED IT WILL THROW AN ERROR
            catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }


        }
        // METHOD TO GET THE DATA FROM THE FORM
        public void OnGetRecord_Click(object sender, EventArgs e)
        {
           
            SqlConnection conn = new SqlConnection(inout.str);
            //opening the connection 
            conn.Open();
            string message = User.Identity.GetUserName();
            //QUERING THE DATA
            Name = Request.Query["names"];
            Email = message?.ToString();
            users = "USER: " + Name;
            // MAKING A UNIQUE KEY
            string module_id = Email + Name;
            string selectquery = $"Select students.passkey from students where student_num ='{Email}';";
            SqlCommand mysql = new SqlCommand(selectquery, conn);
            SqlDataReader reader = mysql.ExecuteReader();
            // reading the data
            reader.Read();
            SetName = reader[0].ToString();
            reader.Close();

            W1 = Request.Query["week1"];

            inout.W1 = double.Parse(W1);
            // ALL THIS GETS THE DATA FROM THE USER
            Date1 = Request.Query["date1"];
            Date2 = Request.Query["date2"];
            Date3 = Request.Query["date3"];
            Date4 = Request.Query["date4"];


            W2 = Request.Query["w2"];
            W3 = Request.Query["w3"];
            W4 = Request.Query["w4"];

            inout.W2 = double.Parse(W2);
            inout.W3 = double.Parse(W3);
            inout.W4 = double.Parse(W4);
            hours1 = Request.Query["hours1"];
            hours2 = Request.Query["hours2"];
            hours3 = Request.Query["hours3"];
            hours4 = Request.Query["hours4"];
            inout.hours1 = double.Parse(hours1);
            inout.hours2 = double.Parse(hours2);
            inout.hours3 = double.Parse(hours3);
            inout.hours4 = double.Parse(hours4);
            credits1 = Request.Query["credits1"];
            credits2 = Request.Query["credits2"];
            credits3 = Request.Query["credits3"];
            credits4 = Request.Query["credits4"];
            inout.credits1 = double.Parse(credits1);
            inout.credits2 = double.Parse(credits2);
            inout.credits3 = double.Parse(credits3);
            inout.credits4 = double.Parse(credits4);

             // SQL QUERY FOR THE IF STATEMENT TO VALIDATE DATA 
            string selectquery1 = $"Select module1.student_name_id from module1 where student_num ='{Email}';";
            SqlCommand mysql1 = new SqlCommand(selectquery1, conn);
            SqlDataReader reader1 = mysql1.ExecuteReader();
            // reading the data
            // IF THE DATA MATCHES THE PROGRAM WILL RUN NORMALLY
            reader1.Read();
            if (module_id == reader1[0].ToString())
            {
                heading1 = "MODULE 1";
                heading2 = "MODULE 2";
                heading3 = "MODULE 3";
                heading4 = "MODULE 4";
                Module1fucntion();
                module2();
                Module3();
                Module4();

            }
            //IF NOT THEN AN ERROR WILL BE THROWN
            else if (module_id != reader1[0].ToString())
            {
                Error = " UNRECOGNISED USER , PLEASE ENSURE YOU HAVE DONE SUBMISSION FIRST ";

            }



        }


        // MANAGES THE MODULE 1 FUNCTIONS 
        public void Module1fucntion()
        { // ensuring all relevant fields are filled 

            try
            {
                //calling class 1 methods

                inout.Singlemod1();


                // connection string to connect to the databaase
               
                SqlConnection conn = new SqlConnection(inout.str);
                // opening the connection
                conn.Open();
                // creating the unique id per user
                string module_id = Email + Name;
                // passsing it to class 1

                // update query to update the module 1 table
                string updatequery = $"update module1 set module1.sub_date = @date ,module1.module1_weeks = @WEEK, module1.module1_credits = @credits,module1.module1_hours = @hours where module1.student_name_id ='{module_id}';";
                SqlCommand module1 = new SqlCommand(updatequery, conn);
                module1.Parameters.Add("@date", SqlDbType.VarChar, 100).Value = Date1;
                module1.Parameters.Add(@"WEEK", SqlDbType.Int, 100).Value = W1;
                module1.Parameters.Add(@"credits", SqlDbType.Int, 100).Value = credits1;
                module1.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = hours1;

                module1.ExecuteScalar();
                // calling the calculations 
                Module1calculate();

                // select query to select the modules i want to print 
                string selectquery = $"Select module1.sub_date,module1.module1_name,module1.module1_self_study from module1 where module1.student_name_id  ='{module_id}';";

                SqlCommand mysql = new SqlCommand(selectquery, conn);
                SqlDataReader reader = mysql.ExecuteReader();
                // calling the reader
                reader.Read();
                // printing what the reader has read
                Message1 = $"DATE: {reader[0].ToString()}\nMODULE: {reader[1].ToString()}\nSTUDY HOURS: {reader[2].ToString()};\n";
                reader.Close();
                // closing the reader for next use
            }
            // error catching for user made errors
            catch
            {
                Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST";
            }


        }

        /// <summary>
        /// METHOD FOR CALCULATION FOR MODULE 1
        /// </summary>
        public void Module1calculate()
        {
            try
            {
                string module_id = Email + Name;
                //calculation method for module 1
                
                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // opening a connection 

                // selecting the relevent fields for use
                string selectquery = $"Select module1.module1_weeks, module1.module1_credits,module1.module1_hours from module1 where module1.student_name_id  ='{module_id}';";

                SqlCommand mysql = new SqlCommand(selectquery, conn);
                SqlDataReader reader = mysql.ExecuteReader();

                // passing the value to class 1 for calculations 
                reader.Read();
                inout.W1 = double.Parse(reader[0].ToString());
                inout.credits1 = double.Parse(reader[1].ToString());
                inout.hours1 = double.Parse(reader[2].ToString());
                reader.Close();
                // closing the reader for next use

                // updating the table with next values 
                string updatequery = $"update module1 set module1.module1_self_study = @study,module1.module1_remaining_hours = @hours where module1.student_name_id ='{module_id}';";
                SqlCommand module1 = new SqlCommand(updatequery, conn);
                module1.Parameters.Add(@"study", SqlDbType.Int, 100).Value = inout.result1;
                module1.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = inout.result1;

                module1.ExecuteScalar();
            }
            catch
            {// CATCHING THE ERRORS
                Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST";
            }
        }
        //MANAGING THE MODULE 2
        public void module2()
        {
            try
            {




                // calling the class 1 and input fields

                inout.Singlemod2();

                // opening a connection 

                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // creating the unique id
                string module_id = Email + Name;

                // passing the value to class 1

                //updating the module 2 table in the database
                string updatequery = $"update module2 set module2.module2_date = @date ,module2.module2_weeks = @WEEK, module2.module2_credits = @credits,module2.module2_hours = @hours where module2.student_name_id ='{module_id}';";
                SqlCommand module2 = new SqlCommand(updatequery, conn);

                module2.Parameters.Add(@"date", SqlDbType.VarChar, 100).Value = Date2;
                module2.Parameters.Add(@"WEEK", SqlDbType.Int, 100).Value = W2;
                module2.Parameters.Add(@"credits", SqlDbType.Int, 100).Value = credits2;
                module2.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = hours2;
                module2.ExecuteScalar();

                // calling the calculations for the module 2 method
                Module2calculate();



                // selecting the rlevent fields for printing 
                string selectquery = $"Select module2.module2_date, module2.module2_name,module2.module2_self_study from module2 where module2.student_name_id  ='{module_id}';";

                SqlCommand mysql = new SqlCommand(selectquery, conn);
                SqlDataReader reader = mysql.ExecuteReader();

                // reader is reading the data
                reader.Read();
                // printing the data the reader has read
                Message2 = ($"DATE: {reader[0].ToString()}\nMODULE2: {reader[1].ToString()}'\nSTUDY HOURS: {reader[2].ToString()}';\n");
                reader.Close();
                // closing the data for the next reader
            }
            catch {
                // CATCHING ANY RELATED ERRORS
                Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST";
            }
        }
        //METHOD FOR MODULE 2 CALCULATIONS
        public void Module2calculate()
        {
            string module_id = Email + Name;
            try
            {
                //opening the connection for module 2
                
                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // selecting the needed stuff 
                string selectquery = $"Select module2.module2_weeks, module2.module2_credits,module2.module2_hours from module2 where module2.student_name_id  ='{module_id}';";
                // the sql data reader
                SqlCommand mysql = new SqlCommand(selectquery, conn);
                SqlDataReader reader = mysql.ExecuteReader();

                // reading the data 
                reader.Read();
                inout.W2 = double.Parse(reader[0].ToString());
                inout.credits2 = double.Parse(reader[1].ToString());
                inout.hours2 = double.Parse(reader[2].ToString());
                reader.Close();

                // UPDATING THE DATABASE  WITH NEW DATA 
                string updatequery = $"update module2 set module2.module2_self_study = @study ,module2.module2_remaining_hours = @hours where module2.student_name_id ='{module_id}';";
                SqlCommand module2 = new SqlCommand(updatequery, conn);
                module2.Parameters.Add(@"study", SqlDbType.Int, 100).Value = inout.result2;
                module2.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = inout.result2;

                module2.ExecuteScalar();

            }// CATCHING THE ERRORS
            catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }




        }
        //METHOD TO MANAGE MODULE 3
        public void Module3()
        {
            inout.Singlemod3();

            // OPENNING A CONNECTION 
            try
            {
                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // CREATING THE UNIQUE ID 
                string module_id = Email + Name;
                // UPDATING THE DATABASE
                string updatequery = $"update module3 set module3.module3_date = @date, module3.module3_weeks = @WEEK, module3.module3_credits = @credits,module3.module3_hours = @hours where module3.student_name_id ='{module_id}';";
                SqlCommand module3 = new SqlCommand(updatequery, conn);

                module3.Parameters.Add(@"date", SqlDbType.VarChar, 100).Value = Date3;
                module3.Parameters.Add(@"WEEK", SqlDbType.Int, 100).Value = W3;
                module3.Parameters.Add(@"credits", SqlDbType.Int, 100).Value = credits3;
                module3.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = hours3; ;

                // EXECUTION OF IT 
                module3.ExecuteScalar();
                Module3calculate();



                // SELECT QUERY FOR PRINTING
                string selectquery = $"Select module3.module3_date, module3.module3_name,module3.module3_self_study from module3 where module3.student_name_id  ='{module_id}';";
                // READER IS READING 
                SqlCommand read = new SqlCommand(selectquery, conn);
                SqlDataReader reader = read.ExecuteReader();

                // READING AND PRINTING THEN CLOSING HE READER
                reader.Read();
                Message3 = ($"DATE: {reader[0].ToString()}\nMODULE: {reader[1].ToString()}\nSTUDY HOURS: {reader[2].ToString()};\n");
                reader.Close();
                // CATCHING ANY RELATED ERRRORS
            } catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }
        }
        // METHOD FOR MODULE 3 CALCULATIONS
        public void Module3calculate() {
            try
            {
                string module_id = Email + Name;

                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // SELECT QUERY FOR CALCULATIONS
                string selectquery = $"Select module3.module3_weeks, module3.module3_credits,module3.module3_hours from module3 where module3.student_name_id  ='{module_id}';";
                //EXECUTION OF THE COMMANDS
                SqlCommand module3 = new SqlCommand(selectquery, conn);
                SqlDataReader reader = module3.ExecuteReader();

                //ASSINGING TO THE CLASS 1 DATA VARIABLES
                reader.Read();
                inout.W3 = double.Parse(reader[0].ToString());
                inout.credits3 = double.Parse(reader[1].ToString());
                inout.hours3 = double.Parse(reader[2].ToString());
                reader.Close();

                // UPDATING THE DATABASE WITH THE NEW VALUES 
                string updatequery = $"update module3 set module3.module3_self_study = @study ,module3.module3_remaining_hours = @hours where module3.student_name_id ='{module_id}';";
                SqlCommand module3b = new SqlCommand(updatequery, conn);
                module3b.Parameters.Add(@"study", SqlDbType.Int, 100).Value = inout.result3;
                module3b.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = inout.result3;

                module3b.ExecuteScalar();
            }
            // CATCHING ANY RELATED ERRORS
            catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }
        }
        //METHOD TO MANAGE MODULE 4
        public void Module4() { string module_id = Email + Name;
            inout.Singlemod4();


            // opening a connection
            try
            {


                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // creating the uniqie ID


                // ASSIGNING TO CLASS 1


                // UPDATING THE MODULE 4 TABLE
                string updatequery = $"update module4 set module4.module4_date = @date, module4.module4_weeks = @WEEK, module4.module4_credits = @credits,module4.module4_hours = @hours where module4.student_name_id ='{module_id}';";
                SqlCommand module4 = new SqlCommand(updatequery, conn);
                // ADDING THE VALUES TO THE DATABASE AND CONVERTING TO THE RELVENT TYPES
                module4.Parameters.Add(@"date", SqlDbType.VarChar, 100).Value = Date4;
                module4.Parameters.Add(@"WEEK", SqlDbType.Int, 100).Value = W4;
                module4.Parameters.Add(@"credits", SqlDbType.Int, 100).Value = credits4;
                module4.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = hours4;
                // EXECUTING THE QUERY
                module4.ExecuteScalar();
                Module4calculate();

                // SELECT QUERY FOR PRINTING
                string query = $"Select module4.module4_date,module4.module4_name,module4.module4_self_study from module4 where module4.student_name_id  ='{module_id}';";
                // OPENING THE READER
                SqlCommand mysql = new SqlCommand(query, conn);
                SqlDataReader reader = mysql.ExecuteReader();

                //READER IS READING
                reader.Read();
                Message4 = ($"DATE: {reader[0].ToString()}\nMODULE: {reader[1].ToString()}\nSTUDY HOURS: {reader[2].ToString()} ;\n");
                reader.Close();
            }
            catch { }

        }
        // METHOD FOR MODULE 4 CALCULATIONS
        public void Module4calculate() { string module_id = Email + Name;
            try
            {
                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // CREATING A SELECT QUERY 
                string selectquery = $"Select module4.module4_weeks, module4.module4_credits,module4.module4_hours from module4 where module4.student_name_id  ='{module_id}';";

                // OPENING A READER
                SqlCommand mysql = new SqlCommand(selectquery, conn);
                SqlDataReader reader = mysql.ExecuteReader();
                // READER IS READING THE DATA
                reader.Read();
                // ASSIGNING TO THE CLASS 1 VARIABLES
                inout.W4 = double.Parse(reader[0].ToString());
                inout.credits4 = double.Parse(reader[1].ToString());
                inout.hours4 = double.Parse(reader[2].ToString());
                // CLOSING THE READER
                reader.Close();

                // CREATING AN UPDATE QUERY 
                string updatequery = $"update module4 set module4.module4_self_study = @study ,module4.module4_remaining_hours = @hours where module4.student_name_id ='{module_id}';";
                SqlCommand module4 = new SqlCommand(updatequery, conn);
                // UPDATING THE RELEVENT FIELD IN THE DATABASE FROM CLASS 1
                module4.Parameters.Add(@"study", SqlDbType.Int, 100).Value = inout.result4;
                module4.Parameters.Add(@"hours", SqlDbType.Int, 100).Value = inout.result4;

                module4.ExecuteScalar();
            }
            catch { }

        }
    }
}