using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using Xceed.Wpf.Toolkit;
using System.Web;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNet.Identity;
using Microsoft.Graph;
using Microsoft.Extensions.Hosting;
using Custom_part_3_Libary;

namespace progpart3.Pages
{

    public class SUBSModel : PageModel
    {// GETTERS AND SETTERS IN ORDER TO GET OUTPUT AND SET OUTPUT
        Class1 inout = new Class1();
        public string? solution { get; set; }
        public string? Message { get; set; }
        public string? Email { get; set; }
        public string? Dates { get; set; }
        public string? Dates2 { get; set; }
        public string? YEAR { get; set; }
        public string? Error { get; set; }
        public string? Name { get; set; }
        public string? Name2 { get; set; }
        public string? Module1 { get; set; }
        public string? Module2 { get; set; }
        public string? Module3 { get; set; }
        public string? Module4 { get; set; }
        public void OnGet()
        {// ON GET IS TO TELL THE HTML I WANT THE VALUE OF THE FORMS 
            try
            { string? message = null;
                message = User.Identity.GetUserName();
                if (  message == null )
                {
                   Error = "Warning! you have not logged in";
                    Response.Redirect("Identity/Account/Login");
                }
                else
                {// ENSURING THE NULL ERROR IS NOT THROWN 
                    Email = message?.ToString();
                }
            }
            catch {  }
        }



        public void OnGetSubmit_Click(object sender, EventArgs e)
        { // the button TO START AND CALL THE METHODS FOR THE FUNCTIONALITY AS WELL AS TO TELL THE METHOD TO EXPECT A VALUE FROM THE HTML 
            string message = User.Identity.GetUserName();
            Email = message?.ToString();
            // GETTING THE VALUES FROM THE HTML FORM AND THE INPUT FIELDS

            // GETTING THE VALUE FROM DATE FIELD
            var date = Request.Query["date"];
            //GETTING THE VALUE OF STUDENT EMAIL
            var studentnumber = Request.Query["st1"];
            //GETTING THE VALUE OF STUDENT NAME
            var names = Request.Query["name1"];

            string year = Request.Query["years"];
            // GETTING VALUE OF MODULE 1
            string m1 = Request.Query["MOD1"];
            // GETTING VALUE OF MODULE 2
            string m2 = Request.Query["MOD2"];
            // GETTING VALUE OF MODULE 3
            string m3 = Request.Query["MOD3"];
            // GETTING VALUE OF MODULE 4
            string m4 = Request.Query["MOD4"];
            //ASSINGING IT TO MY GETTERS AND SETTERS
            Message = $"STUDENT EMAIL: {studentnumber}";
            Dates = $"SUBMISSION DATE: {date}";
            Name = $"STUDENT NAME: {names}";
            // THE CONNEC6TION TO THE DATABASE
            YEAR = year;
            Dates2 = date;
            // ADDING EXTRA VALIDATION TO ENSURE SECURITY 
            Name2 = names + year;
                
            SqlConnection conn = new SqlConnection(inout.str);
            conn.Open();
            //this ensures that even in the event of a bug the students cant see each others work
            string module_id = Email + Name2 ;
            string selectquery2 = $"Select students.student_num from students where student_num ='{Email}';";
            SqlCommand mysql2 = new SqlCommand(selectquery2, conn);
            SqlDataReader reader2 = mysql2.ExecuteReader();
            // reading the data
            // CHECKING IF THE RESUBMISSION NAME IS CORRECT
            if (reader2.HasRows == true)
            {// CHECKING IF THE USER NAME IS CORRECT 
                reader2.Close();
                String selectquery3 = $"Select module1.student_num from module1 where module1.student_name_id ='{module_id}';";
                SqlCommand mysql3 = new SqlCommand(selectquery3, conn);
                SqlDataReader reader3 = mysql3.ExecuteReader();
                if (reader3.HasRows == true)
                {  //UPDATING THE MODULES AND THE DATES
                    reader2.Close();
                    reader3.Close();
                    string insertmodule1 = $"update  module1 set module1.module1_date = @dates,module1.module1_name = @name where module1.student_name_id = '{module_id}';";
                    SqlCommand module1 = new SqlCommand(insertmodule1, conn);
                    module1.Parameters.Add(@"dates", SqlDbType.VarChar, 100).Value = Dates2;
                    module1.Parameters.Add(@"name", SqlDbType.VarChar, 100).Value = m1;
                    module1.ExecuteScalar();

                    //  UPDATED module 2 insertion  into the database
                    string insertmodule2 = $"update  module2 set module2.module2_name = @name where module2.student_name_id = '{module_id}';";
                    SqlCommand module2 = new SqlCommand(insertmodule2, conn);

                    module2.Parameters.Add(@"name", SqlDbType.VarChar, 100).Value = m2;
                    module2.ExecuteScalar();

                    //UPDATED  module3 insertion into the database
                    string insertmodule3 = $"update  module3 set module3.module3_name = @name where module3.student_name_id = '{module_id}';";
                    SqlCommand module3 = new SqlCommand(insertmodule3, conn);

                    module3.Parameters.Add(@"name", SqlDbType.VarChar, 100).Value = m3;
                    module3.ExecuteScalar();

                    // UPDATEDmodule 4 insertion into the database
                    string insertmodule4 = $"update module4 set module4.module4_name = @name where module4.student_name_id = '{module_id}';";
                    SqlCommand module4 = new SqlCommand(insertmodule4, conn);

                    module4.Parameters.Add(@"name", SqlDbType.VarChar, 100).Value = m4;
                    module4.ExecuteScalar();

                    // CALLING THE DATA FOR THE USER TO CHECK 
                    string selectquery = $"Select students.student_num,module1.module1_date,module1.module1_name,module2.module2_name,module3.module3_name,module4.module4_name from ((((module1 inner join students on module1.student_num = students.student_num) inner join module2 on students.student_num = module2.student_num)  inner join module3 on students.student_num = module3.student_num)inner join module4 on students.student_num = module4.student_num) where students.student_num ='{Email}';";

                    SqlCommand mysql = new SqlCommand(selectquery, conn);
                    SqlDataReader reader = mysql.ExecuteReader();
                    // printing for user validation
                    reader.Read();
                    // PRINTING THE VALUES
                    Module1 = $"MODULE 1:{reader[2].ToString()}";
                    Module2 = $"MODULE 2:{reader[3].ToString()}";
                    Module3 = $"MODULE 3:{reader[4].ToString()}";
                    Module4 = $"MODULE 4:{reader[5].ToString()}";
                    reader.Close();
                }// ERROR IF THE NAME DOESNT MATCH
                else { Error = "incorrect name entered"; }


            }
            else
            {
                reader2.Close();
                try
                {

                    // INSERT QUERY 
                    string insertquery = "insert into students(student_num,passkey) VALUES(@student_num,@passkey)";
                    SqlCommand MYSQL2 = new SqlCommand(insertquery, conn);
                    MYSQL2.Parameters.Add(@"student_num", SqlDbType.VarChar, 150).Value = Email;
                    MYSQL2.Parameters.Add(@"passkey", SqlDbType.VarChar, 150).Value = Name2;
                    // EXECUTION!
                    MYSQL2.ExecuteScalar();
                }
                catch
                {
                    // IF THE USERS DONT MATCH
                    Error = "INVALID USER SUBMISSIONS";
                }

                try
                { // module 1 insertion into the database
                    string insertmodule1 = "insert into module1(module1_date,student_num,student_name_id,module1_name) VALUES(@module1_date,@student_num,@student_name_id,@module1_name)";
                    SqlCommand module1 = new SqlCommand(insertmodule1, conn);
                    module1.Parameters.Add(@"module1_date", SqlDbType.VarChar, 100).Value = Dates2;
                    module1.Parameters.Add(@"student_num", SqlDbType.VarChar, 100).Value = Email;
                    module1.Parameters.Add(@"student_name_id", SqlDbType.VarChar, 100).Value = module_id;
                    module1.Parameters.Add(@"module1_name", SqlDbType.VarChar, 100).Value = m1;
                    module1.ExecuteScalar();

                    // module 2 insertion  into the database
                    string insertmodule2 = "insert into module2(student_num,student_name_id,module2_name) VALUES(@student_num,@student_name_id,@module2_name)";
                    SqlCommand module2 = new SqlCommand(insertmodule2, conn);
                    module2.Parameters.Add(@"student_num", SqlDbType.VarChar, 100).Value = Email;
                    module2.Parameters.Add(@"student_name_id", SqlDbType.VarChar, 100).Value = module_id;
                    module2.Parameters.Add(@"module2_name", SqlDbType.VarChar, 100).Value = m2;
                    module2.ExecuteScalar();

                    // module3 insertion into the database
                    string insertmodule3 = "insert into module3(student_num,student_name_id,module3_name) VALUES(@student_num,@student_name_id,@module3_name)";
                    SqlCommand module3 = new SqlCommand(insertmodule3, conn);
                    module3.Parameters.Add(@"student_num", SqlDbType.VarChar, 100).Value = Email;
                    module3.Parameters.Add(@"student_name_id", SqlDbType.VarChar, 100).Value = module_id;
                    module3.Parameters.Add(@"module3_name", SqlDbType.VarChar, 100).Value = m3;
                    module3.ExecuteScalar();

                    //module 4 insertion into the database
                    string insertmodule4 = "insert into module4(student_num,student_name_id,module4_name) VALUES(@student_num,@student_name_id,@module3_name)";
                    SqlCommand module4 = new SqlCommand(insertmodule4, conn);
                    module4.Parameters.Add(@"student_num", SqlDbType.VarChar, 100).Value = Email;
                    module4.Parameters.Add(@"student_name_id", SqlDbType.VarChar, 100).Value = module_id;
                    module4.Parameters.Add(@"module3_name", SqlDbType.VarChar, 100).Value = m4;
                    module4.ExecuteScalar();


                    // UPDATING THE DATABASE TO REPLACE THE DEFAULT VALUES
                    string updatequery = $"update module1 set module1.module1_total_spent = @amount where module1.student_name_id ='{module_id}';";
                    SqlCommand updatemodule1 = new SqlCommand(updatequery, conn);
                    updatemodule1.Parameters.Add(@"amount", SqlDbType.Int, 100).Value = 0;
                    updatemodule1.ExecuteScalar();
                    string updatequery2 = $"update module2 set module2.module2_total_spent = @amount where module2.student_name_id ='{module_id}';";
                    SqlCommand updatemodule2 = new SqlCommand(updatequery2, conn);
                    updatemodule2.Parameters.Add(@"amount", SqlDbType.Int, 100).Value = 0;
                    updatemodule2.ExecuteScalar();
                    string updatequery3 = $"update module3 set module3.module3_total_spent = @amount where module3.student_name_id ='{module_id}';";
                    SqlCommand updatemodule3 = new SqlCommand(updatequery3, conn);
                    updatemodule3.Parameters.Add(@"amount", SqlDbType.Int, 100).Value = 0;
                    updatemodule3.ExecuteScalar();
                    string updatequery4 = $"update module4 set module4.module4_total_spent = @amount where module4.student_name_id ='{module_id}';";
                    SqlCommand updatemodule4 = new SqlCommand(updatequery4, conn);
                    updatemodule4.Parameters.Add(@"amount", SqlDbType.Int, 100).Value = 0;
                    updatemodule4.ExecuteScalar();
                    // selecting the newly inserted data in the database

                    string selectquery = $"Select students.student_num,module1.module1_date,module1.module1_name,module2.module2_name,module3.module3_name,module4.module4_name from ((((module1 inner join students on module1.student_num = students.student_num) inner join module2 on students.student_num = module2.student_num)  inner join module3 on students.student_num = module3.student_num)inner join module4 on students.student_num = module4.student_num) where students.student_num ='{Email}';";

                    SqlCommand mysql = new SqlCommand(selectquery, conn);
                    SqlDataReader reader = mysql.ExecuteReader();
                    // printing for user validation
                    reader.Read();
                    // PRINTING THE VALUES
                    Module1 = $"MODULE 1:{reader[2].ToString()}";
                    Module2 = $"MODULE 2:{reader[3].ToString()}";
                    Module3 = $"MODULE 3:{reader[4].ToString()}";
                    Module4 = $"MODULE 4:{reader[5].ToString()}";
                }
                catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }
            }
        }
     //ATTEMPTED DELETE METHOD
     public void OnGetDelete_Click(object sender, EventArgs e)

        {

            try
            {
                string? message = null;
                message = User.Identity.GetUserName();
                if (message == null)
                {
                    Error = "Warning! you have not logged in";
                    Response.Redirect("Identity/Account/Login");
                }
                else
                {// ENSURING THE NULL ERROR IS NOT THROWN 
                    Email = message?.ToString();
                }
            }
            catch { }
            SqlConnection conn = new SqlConnection(inout.str);
            conn.Open();
           
         

            string deletequery2 = $"delete from module1 where module1.student_num ='{Email}';";
            SqlCommand delete2 = new SqlCommand(deletequery2, conn);
            delete2.ExecuteScalar();
            string deletequery3 = $"delete from module2 where module2.student_num ='{Email}';";
            SqlCommand delete3 = new SqlCommand(deletequery3, conn);
            delete3.ExecuteScalar();
            string deletequery4 = $"delete from module3 where module3.student_num ='{Email}';";
            SqlCommand delete4 = new SqlCommand(deletequery4, conn);
            delete4.ExecuteScalar();
            string deletequery5 = $"delete from module4 where module4.student_num ='{Email}';";
            SqlCommand delete5 = new SqlCommand(deletequery5, conn);
            delete5.ExecuteScalar();
            // delete query 
            string deletequery = $"delete from students where students.student_num ='{Email}';";
            SqlCommand delete = new SqlCommand(deletequery, conn);
            delete.ExecuteScalar();
        }
    }
   
    }
