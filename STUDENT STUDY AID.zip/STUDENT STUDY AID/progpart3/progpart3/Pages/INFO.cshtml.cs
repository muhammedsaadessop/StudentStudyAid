using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace progpart3.Pages
{
    public class INFOModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
