using Custom_part_3_Libary;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Hosting;
using Microsoft.Graph;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace progpart3.Pages
{
    public class RECORDSModel : PageModel
    { // GETTES AND SETTTERS FOR THE DATA 
        Class1 inout = new Class1();
        public string? Message1 { get; set; }
        public string? Message2 { get; set; }
        public string? Message3{ get; set; }

        public string? Message4 { get; set; }
        public string? Message5 { get; set; }
        public string? Message6 { get; set; }
        public string? Message7 { get; set; }

        public string? Message8 { get; set; }
        public string? Email { get; set; }
        public string? Error { get; set; }

        public string? Hours1 { get; set; }
        public string? Hours2 { get; set; }
        public string? Hours3 { get; set; }
        public string? Hours4 { get; set; }
        public string? Username { get; set; }
        public string? dates { get; set; }
        public string? M1 { get; set; }
        public string? M2 { get; set; }
        public string? M3 { get; set; }

        public string? M4 { get; set; }
        // USER VALIDATION ON PAGE CLICK
        public void OnGet()
        {
            


            try
            {
                string? message = null;
                message = User.Identity.GetUserName();
                if (message == null)
                {
                    Error = "Warning! you have not logged in";
                    Response.Redirect("/Identity/Account/Login");
                }
                else
                {
                    Email = message?.ToString();
                   
                    SqlConnection conn = new SqlConnection(inout.str);
                    //opening the connection 
                    conn.Open();
                    string selectquery = $"Select students.passkey from students where student_num ='{Email}';";
                    SqlCommand mysql = new SqlCommand(selectquery, conn);
                    SqlDataReader reader = mysql.ExecuteReader();
                    // reading the data
                    reader.Read();
                   Username = reader[0].ToString();
                    reader.Close();
                }
            }
            catch { }

        }
        // METHOD TO MANAGE THGE RECORDS PAGE 
        public void OnGetRecording_Click()
        { // GETTING THE DATA
            dates = Request.Query["DT1"];
            Email = Request.Query["NE1"];
            Username = Request.Query["NS1"];
            Hours1 = Request.Query["H1"];
            Hours2 = Request.Query["H2"];
            Hours3 = Request.Query["H3"];
            Hours4 = Request.Query["H4"];
            records();

        }
        //THIS MANAGES THE  DATABASE AND UPDATES AS WELL AS CALCULATES THE DATA 
        public void records()
        { try
            {
                // CREATING THE UNIQUE NAME
                string module_id = Email + Username;
                // CREATING THE CONNECTION AND OPENING

                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();



                // ASSIGNING THE VARIABLE

                // CREATING THE UPDATE QUERYS AND EXECUTING
                string updatequery4 = $"update module1 set module1.module1_hours_spent = @hours1 where module1.student_name_id ='{module_id}';";
                SqlCommand MSSQL4 = new SqlCommand(updatequery4, conn);
                MSSQL4.Parameters.Add(@"hours1", SqlDbType.Int, 100).Value = Hours1;


                MSSQL4.ExecuteScalar();
                string updatequery5 = $"update module2 set module2.module2_hours_spent = @hours2 where module2.student_name_id ='{module_id}';";
                SqlCommand MSSQL5 = new SqlCommand(updatequery5, conn);
                MSSQL5.Parameters.Add(@"hours2", SqlDbType.Int, 100).Value = Hours2;
                MSSQL5.ExecuteScalar();


                string updatequery6 = $"update module3 set module3.module3_hours_spent = @hours3 where module3.student_name_id ='{module_id}';";
                SqlCommand MSSQL6 = new SqlCommand(updatequery6, conn);
                MSSQL6.Parameters.Add(@"hours3", SqlDbType.Int, 100).Value = Hours3;
                MSSQL6.ExecuteScalar();


                string updatequery7 = $"update module4 set module4.module4_hours_spent = @hours4 where module4.student_name_id ='{module_id}';";
                SqlCommand MSSQL7 = new SqlCommand(updatequery7, conn);
                MSSQL7.Parameters.Add(@"hours4", SqlDbType.Int, 100).Value = Hours4;
                MSSQL7.ExecuteScalar();


                // CALCULATING THE REMAINING HOURS THROUGH THE UPDATE QUERY 
                string updatequery = $"update module1 set module1.module1_remaining_hours = module1.module1_remaining_hours - '{Hours1}'where module1.student_name_id ='{module_id}';";
                SqlCommand MSSQL = new SqlCommand(updatequery, conn);


                MSSQL.ExecuteScalar();
                string updatequery1 = $"update module2 set module2.module2_remaining_hours =  module2.module2_remaining_hours -'{Hours2}' where module2.student_name_id ='{module_id}';";
                SqlCommand MSSQL1 = new SqlCommand(updatequery1, conn);

                MSSQL1.ExecuteScalar();


                string updatequery2 = $"update module3 set module3.module3_remaining_hours = module3.module3_remaining_hours - '{Hours3}' where module3.student_name_id ='{module_id}';";
                SqlCommand MSSQL2 = new SqlCommand(updatequery2, conn);

                MSSQL2.ExecuteScalar();



                string updatequery3 = $"update module4 set module4.module4_remaining_hours =  module4.module4_remaining_hours -'{Hours4}' where module4.student_name_id ='{module_id}';";
                SqlCommand MSSQL3 = new SqlCommand(updatequery3, conn);
                MSSQL3.ExecuteScalar();
                Recordprint();
                Totals();
            }
            // CATCHING ANY ERRORS
            catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }

        }
        // THIS PRINTS THE MAIN RECORDS OF THE DATABASE
        public void Recordprint()
        {// OPENING A CONNECTION
            
            SqlConnection conn = new SqlConnection(inout.str);
            conn.Open();
            // CREATING A UNIQIE ID
            string module_id = Email + Username;
            // SELECT QUERYS TO GET THE RELVENT DATA FOR PRINTING FROM EACH TABLE
            string selectquery = $"Select module1.module1_name, module1.module1_hours_spent,module1.module1_remaining_hours,module1.module1_self_study from module1 where module1.student_name_id  ='{module_id}';";
            SqlCommand mysql = new SqlCommand(selectquery, conn);
            SqlDataReader reader1 = mysql.ExecuteReader();
            // DATA READERS READING
            reader1.Read();
            int check1 =  int.Parse (reader1[2].ToString());
            
            // EACH IF STATEMENT WILL CHECK TO ENSURE THE CALCULATIONS STOP AT 0
            if (check1 > 0)
            {
                // PRINTING THE DATA 
                M1 = $"MODULE 1 : {reader1[0].ToString()}";
                Message1 = ($"RECORDED HOURS:'{reader1[3].ToString()}'\nSPENT HOURS:'{reader1[1].ToString()}'\nREMAINING HOURS:'{reader1[2].ToString()}'");
                reader1.Close();

            }
            // WHEN IT REACHES 0
            else if (check1 < 0)
            { M1 = $"MODULE 1 : {reader1[0].ToString()}";
              Message1 = "HAS REACHED 0 ";
            }
            reader1.Close();
            // CLOSING EACH READER BEFORE NEXT USE

            // MODULE 2 CODE
            string selectquery1 = $"Select module2.module2_name, module2.module2_hours_spent,module2.module2_remaining_hours,module2.module2_self_study from module2 where module2.student_name_id  ='{module_id}';";
            SqlCommand mysql1 = new SqlCommand(selectquery1, conn);
            SqlDataReader reader2 = mysql1.ExecuteReader();

            reader2.Read();
            int check2 = int.Parse(reader2[2].ToString());
            if (check2 > 0)
            {
                M2 = $"MODULE 2 : {reader2[0].ToString()}";
                Message2 = ($"RECORDED HOURS:'{reader2[3].ToString()}'\nSPENT HOURS:'{reader2[1].ToString()}'\nREMAINING HOURS:'{reader2[2].ToString()}'");
                reader2.Close();
            }
            else if (check2 < 0)
            {
                M2 = $"MODULE 2 : {reader2[0].ToString()}";
                Message2 = "HAS REACHED 0 ";

            }
            reader2.Close ();
            // MODULE 2 END 

            //MODULE 3 CODE
            string selectquery2 = $"Select module3.module3_name,module3.module3_hours_spent,module3.module3_remaining_hours,module3.module3_self_study from module3 where module3.student_name_id  ='{module_id}';";
            SqlCommand mysql2 = new SqlCommand(selectquery2, conn);
            SqlDataReader reader3 = mysql2.ExecuteReader();

            reader3.Read();
            int check3 = int.Parse(reader3[2].ToString());

            if (check3 > 0)
            {
                M3 = $"MODULE 3 : {reader3[0].ToString()}";
                Message3 = ($"RECORDED HOURS:'{reader3[3].ToString()}'\nSPENT HOURS:'{reader3[1].ToString()}'\nREMAINING HOURS:'{reader3[2].ToString()}'");
                reader3.Close();
            }
            else if (check3 < 0)
            {

                M3 = $"MODULE 3 : {reader3[0].ToString()}";
                Message3 = "HAS REACHED 0 ";
            }
            reader3.Close ();
            // MODULE 3 END


            //MODULE 4 CODE 
            string selectquery3 = $"Select module4.module4_name,module4.module4_hours_spent,module4.module4_remaining_hours,module4.module4_self_study from module4 where module4.student_name_id  ='{module_id}';";
            SqlCommand mysql3 = new SqlCommand(selectquery3, conn);
            SqlDataReader reader4 = mysql3.ExecuteReader();

            reader4.Read();
            int check4 = int.Parse(reader4[2].ToString());
            if (check4 > 0)
            {
                M4 = $"MODULE 4 : {reader4[0].ToString()} ";
                Message4 = ($"RECORDED HOURS:'{reader4[3].ToString()}'\nSPENT HOURS:'{reader4[1].ToString()}'\nREMAINING HOURS:{reader4[2].ToString()}");
                reader4.Close();
            }
            else if(check4 < 0)
            {

                M4 = $"MODULE 4 : {reader4[0].ToString()}";
                Message4 = "HAS REACHED 0 ";


          
            }
            reader4.Close();
            //MODULE 4 END
        }
        /// <summary>
        /// THIS GETS THE TOTALS FOR EACH OF THE MODULES
        /// </summary>
        public void Totals()
        {
            try
            {
                // OPENING A CONNECTION 
                
                SqlConnection conn = new SqlConnection(inout.str);
                conn.Open();
                // CREATING A UNIQUE ID
                string module_id = Email + Username;

                // CALCULATION FOR EACH COLUMN WITHIN THE UPDATE QUERYS 
                string updatequery = $"update module1 set module1.module1_total_spent = module1.module1_total_spent  + '{Hours1}'where module1.student_name_id ='{module_id}';";
                SqlCommand MSSQL = new SqlCommand(updatequery, conn);


                MSSQL.ExecuteScalar();
                string updatequery1 = $"update module2 set module2.module2_total_spent = module2.module2_total_spent  + '{Hours2}'where module2.student_name_id ='{module_id}';";
                SqlCommand MSSQL1 = new SqlCommand(updatequery1, conn);

                MSSQL1.ExecuteScalar();


                string updatequery2 = $"update module3 set module3.module3_total_spent = module3.module3_total_spent  + '{Hours3}'where module3.student_name_id ='{module_id}';";
                SqlCommand MSSQL2 = new SqlCommand(updatequery2, conn);

                MSSQL2.ExecuteScalar();



                string updatequery3 = $"update module4 set module4.module4_total_spent = module4.module4_total_spent  + '{Hours4}'where module4.student_name_id ='{module_id}';";
                SqlCommand MSSQL3 = new SqlCommand(updatequery3, conn);
                MSSQL3.ExecuteScalar();

                // SELECT QUERYS FOR THE PRINTING OF EACH MODULE
                string moduleselect = $"Select module1.module1_name, module1.module1_total_spent from module1  where module1.student_name_id  ='{module_id}';";
                SqlCommand mssql1 = new SqlCommand(moduleselect, conn);
                SqlDataReader module1 = mssql1.ExecuteReader();
                // DATA READER IS READING
                module1.Read();
                // PRINTING FOR EACH MODULE TO THE FORM
                Message5 =($"MODULE NAME'{module1[0].ToString()}'\nTOTAL HOURS:'{module1[1].ToString()}';");
                module1.Close();
                string module2select = $"Select module2.module2_name, module2.module2_total_spent from module2  where module2.student_name_id  ='{module_id}';";
                SqlCommand mssql2 = new SqlCommand(module2select, conn);
                SqlDataReader module2 = mssql2.ExecuteReader();

                module2.Read();
                Message6 = ($"MODULE NAME'{module2[0].ToString()}'\nTOTAL HOURS:'{module2[1].ToString()}';");
                module2.Close();
                string module3select = $"Select module3.module3_name, module3.module3_total_spent  from module3 where module3.student_name_id  ='{module_id}';";
                SqlCommand mssql3 = new SqlCommand(module3select, conn);
                SqlDataReader module3 = mssql3.ExecuteReader();


                module3.Read();

                Message7 = ($"MODULE NAME'{module3[0].ToString()}'\nTOTAL HOURS:'{module3[1].ToString()}';");
                module3.Close();
                string module4select = $"Select module4.module4_name, module4.module4_total_spent from module4 where module4.student_name_id  ='{module_id}';";
                SqlCommand mssql4 = new SqlCommand(module4select, conn);
                SqlDataReader module4 = mssql4.ExecuteReader();

                module4.Read();
               Message8  = ($"MODULE NAME'{module4[0].ToString()}'\nTOTAL HOURS:'{module4[1].ToString()}';");
                module4.Close();

            } // CATCHINMG THE ERRORS
            catch { Error = "UNRECOGNISED USER , MAKE SURE YOU HAVE SUBMITTED FIRST"; }
           
        }
      
    }
}
