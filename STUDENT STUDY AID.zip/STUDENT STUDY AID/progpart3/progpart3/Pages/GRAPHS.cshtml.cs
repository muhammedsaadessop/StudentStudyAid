using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using System.Data;
using FusionCharts.DataEngine;

using FusionCharts.Visualization;


using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;
using System.Web;
using Microsoft.Data.SqlClient;
using Microsoft.Graph.SecurityNamespace;
using Microsoft.AspNetCore.Http;


using System.Collections.Generic;
using System;
using progpart3.Data;
using Microsoft.Extensions.Hosting;
using Microsoft.Graph;
using Microsoft.AspNet.Identity;
using Custom_part_3_Libary;

namespace progpart3.Pages
{
    public class GRAPHSModel : PageModel
    {// GETTERS AND SETTERS FOR THE GRAPH
        public string? Message1 { get; set; }
        public string? Message2 { get; set; }
        public string? Message3{ get; set; }

        public string? Message4 { get; set; }

        public string? Message5 { get; set; }
        public string? Message6 { get; set; }
        public string? Message7 { get; set; }

        public string? Message8 { get; set; }

        public string? Message9 { get; set; }
        public string? Message10 { get; set; }
        public string? Message11 { get; set; }

        public string? Message12 { get; set; }
        public string? Message13 { get; set; }
        public string? Message14{ get; set; }
        public string? Message15 { get; set; }

        public string? Message16 { get; set; }

        // GETTING THE USER NAME AND EMAIL FOR THE GRAPHG
        public string? Email { get; set; }
        public string? username { get; set; }
        Class1 inout = new Class1();
        private readonly ApplicationDbContext context;
        //ATTEMPTED DB CONTEXT
        public GRAPHSModel(ApplicationDbContext context)
        {
            this.context = context;
        }
        // JSON FORMATTING 
        public string ChartJson { get; internal set; }
        public void OnGet()
        {
            
            //GETTING THE RAW ACCOUNT NAME
            string? message = null;
            message = User.Identity.GetUserName();

            
            //ASSIGNING TO THE EMAIL GETTER 
            Email = message?.ToString();

            SqlConnection conn = new SqlConnection(inout.str2);
            //opening the connection 
            conn.Open();
            try
            {
                string selectquery = $"Select students.passkey from students where student_num ='{Email}';";
                SqlCommand mysql = new SqlCommand(selectquery, conn);
                SqlDataReader reader = mysql.ExecuteReader();
                // reading the data
                // GETTING THE DATA TO POPULATE THE GRAPH
                reader.Read();
                username = reader[0].ToString();
                reader.Close();



                // CREATING A UNIQUE ID
                string module_id = Email + username;

             

                // SELECT QUERYS FOR THE PRINTING OF EACH MODULE
                string moduleselect = $"Select module1.module1_name, module1.module1_total_spent from module1  where module1.student_name_id  ='{module_id}';";
                SqlCommand mssql1 = new SqlCommand(moduleselect, conn);
                SqlDataReader module1 = mssql1.ExecuteReader();
                // DATA READER IS READING
                module1.Read();
                // PRINTING FOR EACH MODULE 
                Message1 = module1[1].ToString();
                module1.Close();
                string module2select = $"Select module2.module2_name, module2.module2_total_spent from module2  where module2.student_name_id  ='{module_id}';";
                SqlCommand mssql2 = new SqlCommand(module2select, conn);
                SqlDataReader module2 = mssql2.ExecuteReader();

                // MODULE 2 READING
                module2.Read();
                Message2 = module2[1].ToString();
                module2.Close();
                string module3select = $"Select module3.module3_name, module3.module3_total_spent  from module3 where module3.student_name_id  ='{module_id}';";
                SqlCommand mssql3 = new SqlCommand(module3select, conn);
                SqlDataReader module3 = mssql3.ExecuteReader();
                module3.Read();

                // MODULE 3 READING
                Message3 = module3[1].ToString();
                module3.Close();
                string module4select = $"Select module4.module4_name, module4.module4_total_spent from module4 where module4.student_name_id  ='{module_id}';";
                SqlCommand mssql4 = new SqlCommand(module4select, conn);
                SqlDataReader module4 = mssql4.ExecuteReader();

                // MODULE 4 READING
                module4.Read();
                Message4 = module4[1].ToString();
                module4.Close();


                string selectquery2 = $"Select module1.module1_name, module1.module1_hours_spent,module1.module1_remaining_hours,module1.module1_self_study from module1 where module1.student_name_id  ='{module_id}';";
                SqlCommand mysql2 = new SqlCommand(selectquery2, conn);
                SqlDataReader reader1 = mysql2.ExecuteReader();
                // DATA READERS READING
                reader1.Read();
                int check1 = int.Parse(reader1[2].ToString());


                // ASSIGNING THE DATA FOR MODULE 1

                Message5 = reader1[3].ToString();
                 Message6 =   reader1[1].ToString();
                Message7 = reader1[2].ToString();
                    reader1.Close();

             

                string selectquery1 = $"Select module2.module2_name, module2.module2_hours_spent,module2.module2_remaining_hours,module2.module2_self_study from module2 where module2.student_name_id  ='{module_id}';";
                SqlCommand mysql1 = new SqlCommand(selectquery1, conn);
                SqlDataReader reader2 = mysql1.ExecuteReader();

                reader2.Read();


                // ASSIGNING THE DATA FOR MODULE 2
                Message8 = reader2[3].ToString();
                Message9 = reader2[1].ToString();
                Message10 = reader2[2].ToString();
                    reader2.Close();
                
                string selectquery6 = $"Select module3.module3_name,module3.module3_hours_spent,module3.module3_remaining_hours,module3.module3_self_study from module3 where module3.student_name_id  ='{module_id}';";
                SqlCommand mysql6 = new SqlCommand(selectquery6, conn);
                SqlDataReader reader3 = mysql6.ExecuteReader();

                reader3.Read();
                // ASSINGING THE DATA FOR MODULE 3
                Message11 = reader3[3].ToString();
                Message12 = reader3[1].ToString();
                Message13 = reader3[2].ToString();
                    reader3.Close();
               
                string selectquery3 = $"Select module4.module4_name,module4.module4_hours_spent,module4.module4_remaining_hours,module4.module4_self_study from module4 where module4.student_name_id  ='{module_id}';";
                SqlCommand mysql3 = new SqlCommand(selectquery3, conn);
                SqlDataReader reader4 = mysql3.ExecuteReader();

                reader4.Read();

                //ASSINGING THE DATA FOR MODULE 4
                Message14 = reader4[3].ToString();
                Message15 = reader4[1].ToString();
                Message16 =  reader4[2].ToString();
                    reader4.Close();
                
            }
            catch { }
            //  TABLE TO STORE THE DATA 
            DataTable Chart = new DataTable();
            // ADDING COLUMNS FOR THE DATA 
            Chart.Columns.Add("HOURS", typeof(System.String));
            Chart.Columns.Add("Number OF MODULES", typeof(System.Double));
            // ADDING ROWS FOR THE DATA 

            var Date = new DateTime(2022, 01, 01);
         
            try
            {
                int M1 = int.Parse(Message1);
                int M2 = int.Parse(Message2);
                int M3 = int.Parse(Message3);
                int M4 = int.Parse(Message4);
                int M5 = int.Parse(Message5); ;
                int M6 = int.Parse(Message8); ;
                int M7 = int.Parse(Message11); 
                int M8 = int.Parse(Message14); 
                int M9 = int.Parse(Message6); 
                int M10 = int.Parse(Message9); 
                int M11 = int.Parse(Message12); 
                int M12 = int.Parse(Message15); 



                Chart.Rows.Add("week 1 - module 1", M1);
                Chart.Rows.Add("MODULE 2", M2);
                Chart.Rows.Add("MODULE 3 ", M3);
                Chart.Rows.Add("MODULE 4", M4);
                Chart.Rows.Add("WEEK 2 MODULE 1", M5);
                Chart.Rows.Add("MODULE 2", M6);
                Chart.Rows.Add("MODULE 3", M7);
                Chart.Rows.Add("MODULE 4", M8);
                Chart.Rows.Add("WEEK 3 MODULE 1", M9);
                Chart.Rows.Add("MODULE 2", M10);
                Chart.Rows.Add("MODULE 3", M11);
                Chart.Rows.Add("MODULE 4", M12);
            
            // Create static source with this data table
            StaticSource source = new StaticSource(Chart);
            // Create instance of DataModel class
            DataModel model = new DataModel();
            // Add DataSource to the DataModel
            model.DataSources.Add(source);
            // Instantiate Column Chart
            Charts.ColumnChart column = new Charts.ColumnChart("student_chart");
            // Set Chart's width and height
            column.Width.Pixel(1000);
            column.Height.Pixel(500);
            // Set DataModel instance as the data source of the chart
            column.Data.Source = model;
            // Set Chart Title
            column.Caption.Text = "USER STUDY HOURS";
            // Set chart sub title
            column.SubCaption.Text = "January - December 2022";
            // hide chart Legend
            column.Legend.Show = false;
            // set XAxis Text
            column.XAxis.Text = "MODULES";
            // Set YAxis title
            column.YAxis.Text = "number of hours";
            // set chart theme
            column.ThemeName = FusionChartsTheme.ThemeName.FUSION;
            // set chart rendering json
            ChartJson = column.Render();
            }
            catch { }
        }






    }
}
